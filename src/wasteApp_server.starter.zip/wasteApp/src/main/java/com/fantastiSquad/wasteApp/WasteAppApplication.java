package com.fantastiSquad.wasteApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WasteAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(WasteAppApplication.class, args);
	}

}
